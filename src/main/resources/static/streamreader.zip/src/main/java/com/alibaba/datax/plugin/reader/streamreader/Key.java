package com.alibaba.datax.plugin.reader.streamreader;

public class Key {

    /**
     * should look like:[{"value":"123","type":"int"},{"value":"hello","type":"string"}]
     */
    public static final String COLUMN = "column";

    public static final String SLICE_RECORD_COUNT = "sliceRecordCount";

}
